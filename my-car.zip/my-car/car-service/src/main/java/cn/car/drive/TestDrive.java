package cn.car.drive;

import java.util.Scanner;

import cn.car.service.Car;
import cn.car.service.impl.CarImpl;

public class TestDrive {
	public static void main(String[] args) {
		Car car = new CarImpl();
		String[][] park = new String[4][4];
		for(int i =0 ;i<4;i++){
			for(int j =0 ;j<4;j++){
				System.out.print("* ");
				park[i][j] = "*";
			}
				System.out.println();
		}
		int x = 1;
		int y = 1;
		while(true){
			Scanner sc = new Scanner(System.in);
			System.out.println("input command:");
			String command = sc.nextLine();
			if (command.equals("go")) park[3-(y-1)][x-1] = "*";
			car.move(command);
			 x = car.getPositionX();
			 y = car.getPositionY();
			if (x < 1 || x >4 || y < 1 ||y > 4) {
				throw new RuntimeException("overstep the boundary!!");
			}
			System.out.println("position:"+"("+x+","+y+")"+"orientation:"+car.getOrientation());
			park[3-(y-1)][x-1] = "C";
			for(int i =0 ;i<4;i++){
				for(int j =0 ;j<4;j++){
					System.out.print(park[i][j]+"");
				}
					System.out.println();
			}
			
		}
	}
}
