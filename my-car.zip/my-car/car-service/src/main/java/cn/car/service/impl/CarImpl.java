package cn.car.service.impl;
import cn.car.service.Car;
public class CarImpl implements Car {

	private int x = 1;
	private int y = 1;
	private String orientation = "N";
	
	public void move(String command) {
		if (command != null && !"".equals(command)) {
			switch (command) {
			case "N":
				orientation = "N";
				break;
			case "S":
				orientation = "S";
				break;
			case "E":
				orientation = "E";
				break;
			case "W":
				orientation = "W";
				break;
			case "go":
				if (orientation.equals("N")) {
					y++;
				}else if (orientation.equals("S")) {
					y--;
				}else if (orientation.equals("E")) {
					x++;
				}else if (orientation.equals("W")) {
					x--;
				}
				break;
				
			default:
				break;
			}
		}
	}

	public int getPositionX() {
		return x;
	}

	public int getPositionY() {
		return y;
	}

	public String getOrientation() {
		return orientation;
	}

}
